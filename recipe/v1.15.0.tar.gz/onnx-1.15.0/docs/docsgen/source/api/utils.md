# onnx.utils

## Extractor

```{eval-rst}
.. autoclass:: onnx.utils.Extractor
    :members:
```

## extract_model

```{eval-rst}
.. autofunction:: onnx.utils.extract_model
```
